# -*- coding: utf-8 -*-
"""
ImageValidatorAgent — Validação rigorosa de imagem ↔ roteiro + timing.

Funcionalidades:
1. Compara cada cena do roteiro com a imagem/vídeo baixado
2. Verifica se o conteúdo visual corresponde ao texto narrado
3. Valida timing: duração da cena vs duração do áudio correspondente
4. Se falhar: deleta asset e solicita regeneração com query corrigida
5. Usa LLM (Gemini) para análise visual + heurísticas rápidas
"""
import os
import json
import time
import hashlib
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict

try:
    from google import genai
    from google.genai import types
    GENAI_AVAILABLE = True
except ImportError:
    GENAI_AVAILABLE = False

from modules.media_engine import get_media_info  # type: ignore


@dataclass
class ValidationResult:
    scene_id: int
    approved: bool
    score: float  # 0-100
    reason: str
    suggestions: List[str]
    timing_ok: bool
    content_ok: bool
    asset_path: str
    asset_type: str  # "image" | "video"
    query_used: str
    regenerate: bool = False
    corrected_query: Optional[str] = None


class ImageValidatorAgent:
    def __init__(
        self,
        cfg: Dict,
        project_dir: Path,
        topic: str,
        script_text: str,
        scenes: List[Dict],
        asset_map: Dict[int, str],
        log_func=print
    ):
        self.cfg = cfg
        self.project_dir = Path(project_dir)
        self.topic = topic
        self.script_text = script_text
        self.scenes = scenes
        self.asset_map = asset_map
        self.log = log_func
        
        # Config
        self.min_score = cfg.get("media", {}).get("image_validator_min_score", 65)
        self.max_retries = cfg.get("media", {}).get("image_validator_max_retries", 3)
        self.use_llm = cfg.get("media", {}).get("image_validator_use_llm", True)
        
        # LLM client
        self.llm_client = None
        if self.use_llm and GENAI_AVAILABLE:
            api_key = os.getenv("GEMINI_API_KEY") or cfg.get("media", {}).get("gemini_api_key")
            if api_key:
                try:
                    self.llm_client = genai.Client(api_key=api_key)
                    self.log(f"[ImageValidator] LLM ativado (Gemini)")
                except Exception as e:
                    self.log(f"[ImageValidator] Falha ao inicializar LLM: {e}", warn=True)
        
        # Extrai segmentos de texto por cena para comparação
        self.scene_texts = self._extract_scene_texts()
    
    def _extract_scene_texts(self) -> Dict[int, str]:
        """Mapeia scene_id -> texto narrado daquela cena."""
        # O script_text já está sincronizado com as cenas via resync_scenes
        # Cada cena tem 'texto' (o trecho narrado) e 'start'/'end' (timing)
        return {s["id"]: s.get("texto", "") for s in self.scenes}
    
    def validate_all(
        self,
        media_agent,  # MediaResearchAgent instance para regenerar
        max_total_retries: int = 5
    ) -> Dict[int, ValidationResult]:
        """Valida todas as cenas, regenerando as que falharem."""
        results = {}
        total_retries = 0
        
        for scene in self.scenes:
            sid = scene["id"]
            asset_path = self.asset_map.get(sid)
            if not asset_path or not os.path.exists(asset_path):
                self.log(f"[ImageValidator] Cena {sid:02d}: asset não encontrado, pulando")
                continue
            
            retry = 0
            while retry <= self.max_retries:
                result = self._validate_scene(scene, asset_path)
                results[sid] = result
                
                if result.approved:
                    self.log(f"[ImageValidator] ✓ Cena {sid:02d} APROVADA (score={result.score:.0f})")
                    break
                
                if retry >= self.max_retries:
                    self.log(f"[ImageValidator] ✗ Cena {sid:02d} REJEITADA após {retry} tentativas: {result.reason}")
                    result.regenerate = False  # Para não loop infinito
                    break
                
                self.log(f"[ImageValidator] ⚠ Cena {sid:02d} REJEITADA (tentativa {retry+1}/{self.max_retries}): {result.reason}")
                
                # Regenera com query corrigida
                if result.corrected_query and media_agent:
                    try:
                        # Remove asset antigo
                        if os.path.exists(asset_path):
                            os.remove(asset_path)
                        
                        # Solicita regeneração
                        new_asset = media_agent.regenerate_scene(
                            scene_id=sid,
                            corrected_query=result.corrected_query,
                            scene_data=scene
                        )
                        if new_asset and os.path.exists(new_asset):
                            asset_path = new_asset
                            self.asset_map[sid] = new_asset
                            self.log(f"[ImageValidator]   Regenerado: {Path(new_asset).name}")
                        else:
                            self.log(f"[ImageValidator]   Falha ao regenerar", warn=True)
                    except Exception as e:
                        self.log(f"[ImageValidator]   Erro na regeneração: {e}", warn=True)
                
                retry += 1
                total_retries += 1
                if total_retries >= max_total_retries:
                    self.log(f"[ImageValidator] Limite global de retries atingido", warn=True)
                    break
        
        return results
    
    def _validate_scene(self, scene: Dict, asset_path: str) -> ValidationResult:
        """Valida uma única cena: conteúdo + timing."""
        sid = scene["id"]
        scene_text = self.scene_texts.get(sid, "")
        asset_type = "video" if scene["tipo"] == "video" else "image"
        query_used = scene.get("query", "") or scene.get("wikimedia_q", "") or scene.get("ai_prompt", "")
        
        # 1. Validação de arquivo básico
        file_ok, file_reason = self._validate_file(asset_path, asset_type)
        if not file_ok:
            return ValidationResult(
                scene_id=sid, approved=False, score=0,
                reason=f"Arquivo inválido: {file_reason}",
                suggestions=["Verificar download", "Tentar fonte alternativa"],
                timing_ok=False, content_ok=False,
                asset_path=asset_path, asset_type=asset_type,
                query_used=query_used, regenerate=True
            )
        
        # 2. Validação de timing
        timing_ok, timing_reason = self._validate_timing(scene, asset_path, asset_type)
        
        # 3. Validação de conteúdo (LLM + heurísticas)
        if self.llm_client and self.use_llm:
            content_ok, content_score, content_reason, suggestions, corrected_query = \
                self._validate_content_llm(scene_text, asset_path, asset_type, query_used, self.topic)
        else:
            content_ok, content_score, content_reason, suggestions, corrected_query = \
                self._validate_content_heuristic(scene_text, query_used, asset_type)
        
        # Score combinado
        final_score = content_score * 0.7 + (100 if timing_ok else 30) * 0.3
        approved = (final_score >= self.min_score) and content_ok and timing_ok
        
        return ValidationResult(
            scene_id=sid,
            approved=approved,
            score=round(final_score, 1),
            reason=content_reason if not content_ok else (timing_reason if not timing_ok else "OK"),
            suggestions=suggestions,
            timing_ok=timing_ok,
            content_ok=content_ok,
            asset_path=asset_path,
            asset_type=asset_type,
            query_used=query_used,
            regenerate=not approved,
            corrected_query=corrected_query if not approved else None
        )
    
    def _validate_file(self, path: str, asset_type: str) -> Tuple[bool, str]:
        """Validação básica de arquivo."""
        if not os.path.exists(path):
            return False, "Arquivo não existe"
        
        size = os.path.getsize(path)
        if asset_type == "video":
            if size < 50_000:  # 50KB mínimo
                return False, f"Vídeo muito pequeno ({size} bytes)"
            # Verifica se é vídeo válido via ffprobe
            try:
                info = get_media_info(path)
                if info.get("duration", 0) < 1.0:
                    return False, "Vídeo muito curto (<1s)"
            except Exception:
                return False, "Não foi possível ler metadados do vídeo"
        else:
            if size < 15_000:  # 15KB mínimo
                return False, f"Imagem muito pequena ({size} bytes)"
            # Valida com PIL
            try:
                from PIL import Image
                with Image.open(path) as im:
                    im.verify()
                with Image.open(path) as im:
                    w, h = im.size
                    if w < 800 or h < 450:
                        return False, f"Resolução baixa: {w}x{h}"
            except Exception as e:
                return False, f"Imagem corrompida: {e}"
        
        return True, "OK"
    
    def _validate_timing(self, scene: Dict, asset_path: str, asset_type: str) -> Tuple[bool, str]:
        """Valida se duração do asset bate com duração da cena."""
        scene_dur = scene.get("duration", 0)
        if scene_dur <= 0:
            return True, "Sem duração definida na cena"
        
        if asset_type == "video":
            try:
                info = get_media_info(asset_path)
                asset_dur = info.get("duration", 0)
                if asset_dur <= 0:
                    return False, "Duração de vídeo inválida"
                # Tolerância: asset pode ser mais longo (loop) mas não muito mais curto
                ratio = asset_dur / scene_dur
                if ratio < 0.8:
                    return False, f"Vídeo curto demais: {asset_dur:.1f}s vs cena {scene_dur:.1f}s (ratio={ratio:.2f})"
                if ratio > 5.0:
                    return False, f"Vídeo longo demais: {asset_dur:.1f}s vs cena {scene_dur:.1f}s"
            except Exception:
                return False, "Erro ao ler duração do vídeo"
        else:
            # Imagem: duração é controlada pelo Ken Burns no visual_processor
            pass
        
        return True, "Timing OK"
    
    def _validate_content_llm(
        self, scene_text: str, asset_path: str, asset_type: str, 
        query_used: str, topic: str
    ) -> Tuple[bool, float, str, List[str], Optional[str]]:
        """Validação via LLM (Gemini) - compara texto vs imagem."""
        try:
            # Prepara arquivo para upload
            if asset_type == "video":
                # Para vídeo, extrai frame do meio
                frame_path = self._extract_middle_frame(asset_path)
                if not frame_path:
                    return self._validate_content_heuristic(scene_text, query_used, asset_type)
                upload_path = frame_path
                mime = "image/jpeg"
            else:
                upload_path = asset_path
                mime = "image/jpeg"
            
            # Upload para Gemini
            uploaded = self.llm_client.files.upload(file=upload_path)
            
            prompt = f"""Analise esta {"imagem" if asset_type=="image" else "frame de vídeo"} para um documentário sobre "{topic}".

TEXTO NARRADO DESTA CENA:
"{scene_text}"

QUERY USADA PARA BUSCAR: "{query_used}"

Avalie (0-100) se a imagem corresponde ao texto narrado.
Critérios:
- Elementos visuais batem com o assunto do texto?
- É apropriada para documentário (não é meme, cartoon, stock genérico)?
- Qualidade visual adequada (não borrada, não watermark pesado)?
- Contexto histórico/temático correto?

Responda APENAS em JSON:
{{
  "score": 0-100,
  "approved": true/false,
  "reason": "explicação breve",
  "suggestions": ["sugestão 1", "sugestão 2"],
  "corrected_query": "query melhorada se score<65"
}}"""
            
            response = self.llm_client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[prompt, uploaded],
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0.1
                )
            )
            
            result = json.loads(response.text)
            return (
                result.get("approved", False),
                float(result.get("score", 0)),
                result.get("reason", "LLM evaluation"),
                result.get("suggestions", []),
                result.get("corrected_query") if not result.get("approved", False) else None
            )
            
        except Exception as e:
            self.log(f"[ImageValidator] LLM falhou: {e}, usando heurística", warn=True)
            return self._validate_content_heuristic(scene_text, query_used, asset_type)
    
    def _extract_middle_frame(self, video_path: str) -> Optional[str]:
        """Extrai frame do meio do vídeo para análise."""
        try:
            info = get_media_info(video_path)
            dur = info.get("duration", 0)
            if dur <= 0:
                return None
            mid = dur / 2
            out_path = str(Path(video_path).with_suffix(".frame.jpg"))
            cmd = [
                self.cfg.get("ffmpeg_path", "ffmpeg"), "-y",
                "-ss", str(mid), "-i", video_path,
                "-vframes", "1", "-q:v", "2", out_path
            ]
            subprocess.run(cmd, capture_output=True, timeout=30)
            if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
                return out_path
        except Exception:
            pass
        return None
    
    def _validate_content_heuristic(
        self, scene_text: str, query_used: str, asset_type: str
    ) -> Tuple[bool, float, str, List[str], Optional[str]]:
        """Validação heurística rápida quando LLM não disponível."""
        # Extrai palavras-chave do texto narrado
        keywords = self._extract_keywords(scene_text)
        query_words = set(query_used.lower().split())
        
        # Overlap entre keywords do texto e query usada
        overlap = len(keywords & query_words) / max(len(keywords), 1)
        
        # Penaliza queries genéricas
        generic_penalty = 0
        generic_terms = ["nature", "city", "people", "background", "abstract", "technology", "business"]
        if any(t in query_used.lower() for t in generic_terms):
            generic_penalty = 15
        
        score = max(0, min(100, overlap * 100 - generic_penalty))
        approved = score >= self.min_score
        
        if not approved:
            # Sugere query mais específica baseada no texto
            corrected = self._suggest_corrected_query(scene_text, query_used)
            return False, score, f"Baixo overlap texto-query ({overlap:.0%})", \
                ["Query muito genérica", "Adicionar termos específicos do texto"], corrected
        
        return True, score, "Heurística: overlap texto-query adequado", [], None
    
    def _extract_keywords(self, text: str) -> set:
        """Extrai palavras-chave relevantes do texto."""
        import re
        stopwords = {
            "a", "o", "e", "de", "da", "do", "em", "para", "com", "por", "que",
            "um", "uma", "os", "as", "se", "na", "no", "as", "ao", "aos",
            "é", "foi", "era", "são", "eram", "tem", "tinha", "há", "havia",
            "mais", "menos", "muito", "pouco", "todo", "toda", "todos", "todas",
            "este", "esta", "esse", "essa", "aquele", "aquela", "isto", "aquilo",
            "seu", "sua", "seus", "suas", "meu", "minha", "nosso", "nossa",
            "ele", "ela", "eles", "elas", "você", "vocês", "nós", "eu"
        }
        words = re.findall(r'\b[À-ÿa-z]{4,}\b', text.lower())
        return {w for w in words if w not in stopwords and len(w) > 3}
    
    def _suggest_corrected_query(self, scene_text: str, old_query: str) -> str:
        """Sugere query corrigida baseada no texto da cena."""
        keywords = self._extract_keywords(scene_text)
        # Pega top 3 keywords mais longas/específicas
        top_kw = sorted(keywords, key=len, reverse=True)[:3]
        base = " ".join(top_kw)
        return f"{base} documentary historical footage archival".strip()


def validate_scene_assets(
    cfg: Dict,
    project_dir: Path,
    topic: str,
    script_text: str,
    scenes: List[Dict],
    asset_map: Dict[int, str],
    media_agent,
    log_func=print
) -> Dict[int, ValidationResult]:
    """Função de conveniência para validar todos os assets."""
    validator = ImageValidatorAgent(cfg, project_dir, topic, script_text, scenes, asset_map, log_func)
    return validator.validate_all(media_agent)