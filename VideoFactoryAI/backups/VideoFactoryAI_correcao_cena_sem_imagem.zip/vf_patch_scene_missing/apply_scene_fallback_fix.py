from pathlib import Path
from datetime import datetime
import shutil, sys, py_compile

OLD_SIG = '''    def _validate_asset(self, scene: dict, media_path: str, source_name: str) -> bool:\n'''
NEW_SIG = '''    def _validate_asset(self, scene: dict, media_path: str, source_name: str, remove_on_reject: bool = True) -> bool:\n'''
OLD_REMOVE = '''            # Remove o arquivo reprovado\n            try:\n                if os.path.exists(media_path):\n                    os.remove(media_path)\n            except Exception:\n                pass\n            return False\n'''
NEW_REMOVE = '''            # Por padrão, remove candidatos reprovados para tentar outra fonte.\n            # O fallback final pode desativar a remoção para nunca devolver um\n            # caminho de arquivo inexistente ao pipeline.\n            if remove_on_reject:\n                try:\n                    if os.path.exists(media_path):\n                        os.remove(media_path)\n                except Exception:\n                    pass\n            return False\n'''
OLD_CALL = '''        if not self._validate_asset(scene, dest_path, "pil_fallback"):\n            pass  # Aceita mesmo assim como último recurso\n'''
NEW_CALL = '''        # Último recurso: mesmo que a heurística de relevância reprove o card\n        # procedural, não o apague. Antes isso removia o arquivo e, em seguida,\n        # o asset_map recebia um caminho inexistente, deixando a cena sem visual.\n        if not self._validate_asset(scene, dest_path, "pil_fallback", remove_on_reject=False):\n            if not os.path.isfile(dest_path) or os.path.getsize(dest_path) == 0:\n                # Recria o fallback se uma validação/extensão externa o removeu.\n                url, lic = _l4_pil_card(scene.get("descricao", f"Cena {sid}"), dest_path, scene_id=sid)\n            print(f"    [L4-PIL] Fallback mantido como último recurso para cena {sid:02d}; revisão de relevância recomendada.")\n'''

def main():
    if len(sys.argv) != 2:
        print('Uso: python apply_scene_fallback_fix.py "C:\\Fabrica-de-videos\\VideoFactoryAI"')
        return 2
    root = Path(sys.argv[1]).resolve()
    target = root / 'media_research_agent.py'
    if not target.is_file():
        print(f'[ERRO] Não encontrei: {target}')
        return 2
    src = target.read_text(encoding='utf-8')
    if 'remove_on_reject: bool = True' in src and 'remove_on_reject=False' in src:
        print('[INFO] Correção já está aplicada; nenhuma alteração feita.')
        return 0
    for label, needle in [('assinatura', OLD_SIG), ('remoção de rejeitados', OLD_REMOVE), ('fallback PIL', OLD_CALL)]:
        if src.count(needle) != 1:
            print(f'[ERRO] O bloco esperado para {label} não foi encontrado exatamente uma vez. Arquivo não alterado.')
            return 3
    backup_dir = root / 'backups' / f'patch_fallback_cena_{datetime.now():%Y%m%d_%H%M%S}'
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup = backup_dir / target.name
    shutil.copy2(target, backup)
    patched = src.replace(OLD_SIG, NEW_SIG, 1).replace(OLD_REMOVE, NEW_REMOVE, 1).replace(OLD_CALL, NEW_CALL, 1)
    temp = target.with_suffix('.py.patchtmp')
    temp.write_text(patched, encoding='utf-8', newline='')
    try:
        py_compile.compile(str(temp), doraise=True)
        temp.replace(target)
    except Exception:
        try: temp.unlink(missing_ok=True)
        except Exception: pass
        shutil.copy2(backup, target)
        raise
    print(f'[OK] Correção aplicada. Backup: {backup}')
    print('[OK] O fallback final não será apagado só porque a heurística o reprovou.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
