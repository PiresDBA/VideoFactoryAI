# Correção: cena sem arquivo visual após reprovação

## Causa identificada

No `media_research_agent.py`, `_validate_asset()` apagava qualquer arquivo reprovado. No último fallback (`pil_fallback`), o chamador ignorava o resultado da reprovação e retornava mesmo assim o caminho. Resultado: o arquivo podia já ter sido apagado e a cena ficava sem mídia.

O log também mostra um segundo problema: o avaliador reprova imagens com `overlap cena-query=0` e `tema-query=0`, embora a consulta esteja em inglês e o roteiro em português. Esta correção impede o caminho inexistente, mas **não resolve sozinha a avaliação semântica multilíngue**.

## Aplicar
1. Pare o VideoFactoryAI.
2. Extraia este ZIP numa pasta temporária, fora do projeto.
3. Execute:

```bat
C:\Docling\venv\Scripts\python.exe apply_scene_fallback_fix.py C:\Fabrica-de-videos\VideoFactoryAI
```

4. Confirme a mensagem `[OK] Correção aplicada`.
5. Faça um teste com poucas cenas antes de executar o projeto inteiro.

O instalador cria backup automático em `VideoFactoryAI\backups\patch_fallback_cena_DATA_HORA\` e só altera o arquivo se os três trechos esperados forem encontrados exatamente uma vez.

## Limitação importante

Se todas as fontes reais/geradas forem reprovadas, o último recurso pode ser o card procedural de 1920×1080 com o texto da cena — não uma fotografia temática. Para corrigir adequadamente os falsos negativos sem aceitar imagens irrelevantes, é necessário revisar `image_evaluator_agent.py` e seus critérios multilíngues. Não desative o avaliador globalmente.

## Testes feitos
- Compilação sintática do instalador.
- Aplicação em cópia de teste de `media_research_agent.py`.
- Compilação sintática do arquivo corrigido.
- Verificação de que o fallback usa `remove_on_reject=False`.

Não foi executada uma produção real do VideoFactoryAI.
