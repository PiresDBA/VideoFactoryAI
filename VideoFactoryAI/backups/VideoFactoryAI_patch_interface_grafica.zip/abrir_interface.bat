@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python nao foi encontrado no PATH.
  echo Instale Python 3.10+ ou execute a interface com o mesmo ambiente Python do VideoFactoryAI.
  pause
  exit /b 1
)
python videofactory_gui.py
if errorlevel 1 pause
