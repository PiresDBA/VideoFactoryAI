# Apply small, guarded VideoFactoryAI patches to a project folder.
# Run with the project's Python: python apply_safe_patches.py C:\\Fabrica-de-videos\\VideoFactoryAI
from pathlib import Path
import sys, shutil, datetime

if len(sys.argv) != 2:
    raise SystemExit('Uso: python apply_safe_patches.py <pasta-raiz-do-VideoFactoryAI>')
root = Path(sys.argv[1]).expanduser().resolve()
if not (root / 'agent.py').is_file():
    raise SystemExit(f'Pasta inválida: não encontrei agent.py em {root}')

stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
backup = root / 'backups' / f'patch_safe_{stamp}'
backup.mkdir(parents=True, exist_ok=False)

# GUI: installs the reviewed replacement shipped beside this script.
source_gui = Path(__file__).with_name('videofactory_gui.py')
target_gui = root / 'videofactory_gui.py'
if not source_gui.is_file():
    raise SystemExit('Não encontrei videofactory_gui.py de patch ao lado do script.')
shutil.copy2(target_gui, backup / target_gui.name)
if source_gui.resolve() != target_gui.resolve():
    shutil.copy2(source_gui, target_gui)
else:
    print('[INFO] A GUI já está no caminho de destino; sem cópia redundante.')
print(f'[OK] GUI atualizada; backup: {backup / target_gui.name}')

# Preserve a previously generated narration: it must reach generate_voice() so its
# existing-file reuse guard can work. Only remove subtitle/concat intermediates.
agent = root / 'agent.py'
agent_text = agent.read_text(encoding='utf-8-sig')
old_cleanup = 'for f in [Path(audio_path), Path(srt_path_file), Path(manifest_path)]:'
new_cleanup = 'for f in [Path(srt_path_file), Path(manifest_path)]:'
if old_cleanup in agent_text:
    shutil.copy2(agent, backup / agent.name)
    agent_text = agent_text.replace(old_cleanup, new_cleanup, 1)
    agent.write_text(agent_text, encoding='utf-8', newline='')
    print(f'[OK] Preservação de narracao.mp3 ativada; backup: {backup / agent.name}')
elif new_cleanup in agent_text:
    print('[INFO] agent.py já preserva narracao.mp3; sem alteração.')
else:
    print('[AVISO] Não alterei a limpeza do áudio: padrão não reconhecido em agent.py. Verifique manualmente.')

# MediaResearchAgent: add a regeneration entry point only if absent.
media = root / 'media_research_agent.py'
if media.is_file():
    text = media.read_text(encoding='utf-8')
    if '    def regenerate_scene(' not in text:
        marker = '    def source_all(self, scenes: List[dict], topic: str = "") -> Dict[int, str]:\n'
        method = '''    def regenerate_scene(self, scene_id: int, corrected_query: str, scene_data: dict):
        """Acquire a replacement asset for a rejected scene without overwriting its current file first."""
        import copy, time
        if not corrected_query or not corrected_query.strip():
            return None
        scene = copy.deepcopy(scene_data)
        scene["id"] = int(scene_id)
        scene["query"] = corrected_query.strip()
        scene["wikimedia_q"] = corrected_query.strip()
        old_name = Path(str(scene.get("arquivo") or f"cena_{scene_id:02d}"))
        suffix = old_name.suffix or (".mp4" if scene.get("tipo") == "video" else ".jpg")
        scene["arquivo"] = f"cena_{int(scene_id):02d}_replacement_{int(time.time() * 1000)}{suffix}"
        # source_scene writes to the unique replacement path; original remains intact on failure.
        result = self.source_scene(scene)
        if result and os.path.isfile(result) and os.path.getsize(result) > 0:
            return result
        return None

'''
        if marker not in text:
            print('[AVISO] Não injetei regenerate_scene: ponto de inserção não reconhecido; GUI foi atualizada.')
        else:
            shutil.copy2(media, backup / media.name)
            media.write_text(text.replace(marker, method + marker, 1), encoding='utf-8', newline='')
            print(f'[OK] regenerate_scene adicionado; backup: {backup / media.name}')
    else:
        print('[INFO] regenerate_scene já existe; sem alteração no agente de mídia.')
else:
    print('[AVISO] media_research_agent.py não encontrado; pulei a integração de regeneração.')

print('Aplicação concluída. Não foram executadas produções nem alterados config.yaml/credenciais.')
