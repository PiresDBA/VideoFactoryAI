# Testes e limites conhecidos

## Verificações executadas na preparação
- A GUI de origem foi lida e a inserção do botão e do método `Salvar log` foi confirmada por correspondência textual.
- O método `regenerate_scene` é injetado apenas quando não existe, e apenas se a assinatura de `source_all` usada como ponto de inserção estiver presente.
- O instalador exige que `agent.py` exista na raiz indicada e cria cópias de backup antes de substituir a GUI ou editar `media_research_agent.py`.

## Testes que ainda precisam ser executados no Windows do projeto
1. `python -m py_compile videofactory_gui.py media_research_agent.py`.
2. Abrir a GUI, adicionar texto ao log, salvar duas vezes e confirmar `logs/makete_ho.log` e `logs/makete_ho2.log`, com conteúdo UTF-8 e sem limpar o log visível.
3. Em uma cópia de teste, chamar `regenerate_scene` com uma cena válida e verificar que a mídia anterior permanece no disco até existir substituta.
4. Executar a suíte já existente do projeto e uma produção curta antes de atualizar a instalação principal.

## Não declarado como validado
- XTTS com narração longa, timeout real de subprocesso, concatenação de chunks e fallback.
- Compatibilidade completa de `ImageValidatorAgent` com o agente de mídia e com checkpoints.
- Similaridade visual/perceptual entre mídias diferentes em bytes.
- Fluxo interativo para escolher reutilizar/regenerar/cancelar a narração.
- Produção completa, GPU, FFmpeg e APIs externas.

- Correção adicional: o instalador remove `Path(audio_path)` da lista de arquivos apagados em execução nova, preservando `narracao.mp3`; `agent.py` é copiado para backup antes da edição. Testar em uma cópia do projeto antes de executar produção real.
