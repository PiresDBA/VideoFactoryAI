# VideoFactoryAI — pacote de correções conservadoras

## Conteúdo
- `videofactory_gui.py`: substituição da GUI com botão **Salvar log** (UTF-8, não apaga o texto) e nomes sequenciais `makete_ho.log`, `makete_ho2.log` etc. em `<pasta do projeto>/logs/`.
- `apply_safe_patches.py`: instalador com validação da pasta e backup datado dos arquivos que alterar. Também adiciona `MediaResearchAgent.regenerate_scene()` quando não existe, usando nome de arquivo único para não sobrescrever a mídia atual antes de obter substituta.
- `TESTES_E_LIMITACOES.md`: escopo e verificações.

## Aplicação
1. Faça backup completo do projeto e feche o VideoFactoryAI.
2. Extraia o ZIP em uma pasta temporária, fora da pasta do projeto.
3. Execute no Windows:
   `C:\Docling\venv\Scripts\python.exe apply_safe_patches.py C:\Fabrica-de-videos\VideoFactoryAI`
4. Leia o resumo. Os backups criados pelo instalador ficam em `backups/patch_safe_AAAAMMDD_HHMMSS/` dentro do projeto.
5. Abra a GUI e teste **Salvar log** antes de iniciar uma produção real.

O instalador não altera `config.yaml`, chaves de API, checkpoints, resolução, nem remove arquivos existentes. Se não reconhecer o ponto de inserção do agente de mídia, ele avisa em vez de modificar aquele arquivo às cegas.

## Importante
Este pacote é um patch parcial de baixo risco baseado nos arquivos de GUI e pesquisa de mídia disponíveis para inspeção. Ele não deve ser confundido com uma atualização integral do projeto: as correções do `ImageValidatorAgent`, XTTS worker/engine, política de reutilização da narração, detecção perceptual de duplicatas e diagnósticos completos exigem validação contra as versões exatas desses arquivos no diretório instalado. Não aplique substituições cegas nesses módulos.
