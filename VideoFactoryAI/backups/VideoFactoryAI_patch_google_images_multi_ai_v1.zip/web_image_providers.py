"""Busca de imagens no Google Imagens e geração por interfaces web.

Este módulo não usa APIs pagas. Playwright abre perfis persistentes por provedor.
A interface dos serviços pode mudar e exigir login/captcha; falhas retornam None.
Nenhum placeholder é criado. Google Images filtra por Creative Commons, mas a licença
individual do arquivo deve ser verificada na página de origem antes de uso comercial.
"""
from __future__ import annotations
import base64, io, os, re, time
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import quote_plus

MIN_BYTES = 15_000
PROVIDERS = {
    "chatgpt": {
        "url": "https://chatgpt.com/",
        "profile": "chatgpt",
        "composers": ['#prompt-textarea', '[contenteditable="true"][data-placeholder]', 'div[contenteditable="true"]', 'textarea'],
        "send": ['button[data-testid="send-button"]', 'button[aria-label*="Send"]', 'button[aria-label*="Enviar"]'],
    },
    "copilot": {
        "url": "https://copilot.microsoft.com/",
        "profile": "copilot",
        "composers": ['textarea', 'div[contenteditable="true"]', '[role="textbox"]'],
        "send": ['button[aria-label*="Submit"]', 'button[aria-label*="Send"]', 'button[aria-label*="Enviar"]'],
    },
    "dreamina": {
        "url": "https://dreamina.capcut.com/ai-tool/image-generator",
        "profile": "dreamina",
        "composers": ['textarea', '[contenteditable="true"]', '[role="textbox"]', 'input[type="text"]'],
        "send": ['button[aria-label*="Generate"]', 'button[aria-label*="Create"]', 'button:has-text("Generate")', 'button:has-text("Gerar")', 'button:has-text("Create")'],
    },
}


def _profiles_root() -> Path:
    return Path(os.environ.get("VF_WEB_IMAGE_PROFILES", str(Path.home() / ".videofactory_web_image_profiles"))).expanduser().resolve()


def _normalize(data: bytes, dest_path: str) -> bool:
    try:
        from PIL import Image, ImageOps
        img = Image.open(io.BytesIO(data)); img.load()
        if img.width < 768 or img.height < 432:
            return False
        img = ImageOps.fit(img.convert("RGB"), (1920,1080), method=Image.Resampling.LANCZOS, centering=(0.5,0.5))
        dest = Path(dest_path); dest.parent.mkdir(parents=True, exist_ok=True)
        img.save(dest, "JPEG", quality=94, optimize=True)
        return dest.is_file() and dest.stat().st_size >= MIN_BYTES
    except Exception:
        return False


def _download_candidate(page, src: str) -> Optional[bytes]:
    try:
        if src.startswith("data:") and "," in src:
            head, payload = src.split(",",1)
            return base64.b64decode(payload) if ";base64" in head else payload.encode()
        response = page.request.get(src, timeout=15000)
        if response.ok:
            data = response.body()
            if len(data) >= MIN_BYTES and (data.startswith(b"\xff\xd8") or data.startswith(b"\x89PNG\r\n\x1a\n") or data.startswith(b"RIFF")):
                return data
    except Exception:
        pass
    return None


def _extract_image(page) -> Optional[bytes]:
    # First try an actual download button; do not use screenshots of the browser.
    selectors = ['button[aria-label*="Download"]','button[aria-label*="download"]','button[aria-label*="Baixar"]','button[title*="Download"]','button[title*="download"]']
    for sel in selectors:
        try:
            buttons=page.locator(sel)
            for i in range(buttons.count()-1,-1,-1):
                b=buttons.nth(i)
                if not b.is_visible(timeout=250): continue
                try:
                    with page.expect_download(timeout=1800) as info: b.click(timeout=1200)
                    d=info.value; tmp=Path(d.path()) if d.path() else None
                    if tmp and tmp.exists():
                        data=tmp.read_bytes()
                        if len(data)>=MIN_BYTES: return data
                    # Save through Playwright to avoid temporary path assumptions.
                    target=_profiles_root()/f"download_{int(time.time()*1000)}{Path(d.suggested_filename or 'image.jpg').suffix}"
                    target.parent.mkdir(parents=True,exist_ok=True); d.save_as(str(target))
                    data=target.read_bytes(); target.unlink(missing_ok=True)
                    if len(data)>=MIN_BYTES: return data
                except Exception: continue
        except Exception: pass
    candidates=[]
    try:
        imgs=page.locator("img")
        for i in range(max(0,imgs.count()-50),imgs.count()):
            try:
                m=imgs.nth(i).evaluate("e=>({src:e.currentSrc||e.src||'',w:e.naturalWidth||0,h:e.naturalHeight||0})")
                if m['src'] and m['w']>=768 and m['h']>=432 and not m['src'].startswith('blob:'):
                    candidates.append(m)
            except Exception: pass
    except Exception: pass
    candidates.sort(key=lambda x:x['w']*x['h'],reverse=True)
    for item in candidates:
        data=_download_candidate(page,item['src'])
        if data: return data
    return None


def search_google_images(query: str, dest_path: str) -> Optional[Tuple[str,str]]:
    """Busca Google Imagens com filtro de licença Creative Commons e tenta obter bytes de imagem.

    O filtro não substitui a verificação da licença na página de origem.
    """
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        raise RuntimeError("Playwright não está instalado.") from exc
    pw=context=page=None
    try:
        prof=_profiles_root()/"google_images"; prof.mkdir(parents=True,exist_ok=True)
        pw=sync_playwright().start()
        context=pw.chromium.launch_persistent_context(str(prof),headless=False,accept_downloads=True,viewport={"width":1440,"height":1000},args=["--disable-blink-features=AutomationControlled"])
        page=context.pages[0] if context.pages else context.new_page()
        url="https://www.google.com/search?tbm=isch&tbs=il:cl&q="+quote_plus(query)
        page.goto(url,wait_until="domcontentloaded",timeout=45000); page.wait_for_timeout(1800)
        # Google results are thumbnails first. Open a result and inspect large images from the preview.
        for idx in range(min(8,page.locator('div[data-ri]').count())):
            try:
                card=page.locator('div[data-ri]').nth(idx)
                card.click(timeout=1800); page.wait_for_timeout(500)
                data=_extract_image(page)
                if data and _normalize(data,dest_path):
                    # The page may not expose a stable source URL; record the search URL honestly.
                    return (page.url, "Creative Commons filter in Google Images; verify source license")
            except Exception: continue
        # Fallback: inspect result images, but still require a sufficiently large real image.
        data=_extract_image(page)
        if data and _normalize(data,dest_path):
            return (url, "Creative Commons filter in Google Images; verify source license")
        return None
    except Exception as exc:
        print(f"    [Google Images] Falha: {exc}")
        try: Path(dest_path).unlink(missing_ok=True)
        except Exception: pass
        return None
    finally:
        try:
            if context: context.close()
        except Exception: pass
        try:
            if pw: pw.stop()
        except Exception: pass


def generate_image(provider: str, prompt: str, dest_path: str, scene_id: int = 1, topic: str = "") -> Optional[Tuple[str,str]]:
    """Gera imagem pela interface web do provedor e recupera arquivo real, se exposto."""
    provider=(provider or "").strip().lower()
    if provider not in PROVIDERS:
        return None
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        raise RuntimeError("Playwright não está instalado.") from exc
    pw=context=page=None
    try:
        cfg=PROVIDERS[provider]
        profile=_profiles_root()/provider; profile.mkdir(parents=True,exist_ok=True)
        pw=sync_playwright().start()
        context=pw.chromium.launch_persistent_context(str(profile),headless=False,accept_downloads=True,viewport={"width":1440,"height":1000},args=["--disable-blink-features=AutomationControlled"])
        page=context.pages[0] if context.pages else context.new_page()
        page.goto(os.environ.get(f"VF_{provider.upper()}_URL",cfg['url']),wait_until="domcontentloaded",timeout=60000)
        page.wait_for_timeout(1800)
        composer=None
        for sel in cfg['composers']:
            try:
                loc=page.locator(sel).last
                if loc.count() and loc.is_visible(timeout=500): composer=loc; break
            except Exception: pass
        if composer is None:
            raise RuntimeError("Campo de prompt não encontrado; faça login ou a interface mudou.")
        instruction=("Create/generate an original landscape image for a documentary scene. "
                     "Target 16:9, 1920x1080 where supported. No text, captions, logos, or watermarks. "
                     "Do not impose a cinematic style unless it serves the scene.\n"
                     f"Video topic: {topic or 'unspecified'}\nScene {scene_id}: {prompt}\n"
                     "Generate the actual image, not a textual description.")
        composer.click(timeout=4000); composer.fill(instruction,timeout=7000)
        sent=False
        for sel in cfg['send']:
            try:
                btn=page.locator(sel).last
                if btn.count() and btn.is_visible(timeout=300): btn.click(timeout=1800); sent=True; break
            except Exception: pass
        if not sent: composer.press("Enter",timeout=2500)
        timeout=max(45,int(os.environ.get("VF_WEB_IMAGE_TIMEOUT","180")))
        deadline=time.monotonic()+timeout
        data=None; previous_count=-1; stable=0
        while time.monotonic()<deadline:
            page.wait_for_timeout(1500)
            data=_extract_image(page)
            if data: break
            try:
                count=page.locator('img').count()
                stable=stable+1 if count==previous_count else 0; previous_count=count
            except Exception: pass
        if not data:
            raise RuntimeError("Nenhum arquivo de imagem real baixável foi detectado.")
        if not _normalize(data,dest_path):
            raise RuntimeError("Arquivo recuperado não passou na validação de imagem.")
        return (cfg['url'],f"ai_generated_{provider}_webchat")
    except Exception as exc:
        print(f"    [{provider}] Geração falhou: {exc}")
        try: Path(dest_path).unlink(missing_ok=True)
        except Exception: pass
        return None
    finally:
        try:
            if context: context.close()
        except Exception: pass
        try:
            if pw: pw.stop()
        except Exception: pass
