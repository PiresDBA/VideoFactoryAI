# Patch incremental — Google Imagens + geração por ChatGPT, Gemini, Copilot e Dreamina

## Arquivos
- `media_research_agent.py`: patch baseado na versão mais recente compartilhada `media_research_agent(1).py`; adiciona Google Imagens e provedores web antes do fallback já existente.
- `web_image_providers.py`: módulo novo para Google Imagens e geração via interfaces web de ChatGPT, Copilot e Dreamina.
- `gemini_webchat_image.py`: módulo de geração/avaliação via Gemini incluído no patch Gemini anterior.

## Instalação segura
1. Faça backup dos arquivos atuais.
2. Compare `media_research_agent.py` deste ZIP com o arquivo que está instalado. O patch foi aplicado sobre a versão compartilhada mais recente disponível nesta conversa; se você modificou o arquivo depois, não o sobrescreva sem reconciliar as diferenças.
3. Copie os três `.py` para a mesma pasta do `media_research_agent.py`. Não substitua `agent.py`, `config.yaml` nem o avaliador visual.
4. Requer Playwright e Pillow no mesmo Python/venv do VideoFactoryAI. Se Playwright ainda não tiver browsers instalados, instale o Chromium do Playwright.
5. Faça um teste com uma única cena. A primeira execução de cada provedor abre navegador para login manual; os perfis persistem em `~/.videofactory_web_image_profiles/` (Windows: pasta do usuário).

## Configuração por variáveis de ambiente
- `VF_GOOGLE_IMAGES_ENABLED=1` ativa a pesquisa adicional no Google Imagens; `0` desativa.
- `VF_IMAGE_GENERATION_ORDER=gemini,chatgpt,copilot,dreamina` define a ordem de tentativa. Exemplo: `dreamina,chatgpt,gemini,copilot`.
- `VF_WEB_IMAGE_TIMEOUT=180` define o tempo máximo (segundos) de espera para ChatGPT/Copilot/Dreamina.
- `VF_WEB_IMAGE_PROFILES` altera a pasta dos perfis persistentes.
- URLs opcionais: `VF_CHATGPT_URL`, `VF_COPILOT_URL`, `VF_DREAMINA_URL`.

## Google Imagens e licenças
A busca usa o filtro Creative Commons, mas o filtro não garante a licença individual. O relatório registra `Creative Commons filter in Google Images; verify source license`; a licença não é considerada comprovada pelo validador interno. Confira a origem e a licença antes de uso comercial. Google pode exigir captcha, bloquear automação ou alterar a interface.

## Fallbacks preservados
A ordem existente de fontes livres/Openverse permanece. Se os webchats não gerarem ou não permitirem recuperar uma imagem real, o fluxo original Pollinations e o fallback PIL do projeto continuam disponíveis. Portanto, o fallback PIL pode produzir uma arte/cartão procedural conforme o comportamento que já existia; não é uma imagem fotográfica real.

## Limitações e validação
- `py_compile`/AST e integridade do ZIP foram validados.
- Não foi possível validar geração autenticada ou download real em Google, ChatGPT, Gemini, Copilot ou Dreamina neste ambiente. Login, cotas, recursos habilitados e mudanças de interface podem impedir a execução.
- A normalização converte e recorta para 1920×1080; pode cortar parte da composição original.
